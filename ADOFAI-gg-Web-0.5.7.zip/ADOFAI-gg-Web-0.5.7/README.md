# ADOFAI-gg-Web

Web for ADOFAI.gg

## Used source

in `.stylelintrc.js`, [(GitHub) hudochenkov/stylelint-config-hudochenkov/order.js](https://github.com/hudochenkov/stylelint-config-hudochenkov/blob/master/order.js) to sort the css properties
