import React from 'react';
import usePageTracking from '../../usePageTracking';

const PageTracking = () => {
  usePageTracking();
  return <></>;
};

export default PageTracking;
